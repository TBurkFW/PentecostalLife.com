<?php
if(!defined('ABSPATH')) {
    die();
}
?>
<div ng-app="GoogleMerchants" ng-controller="mainController" ng-init="init()">

</div>
