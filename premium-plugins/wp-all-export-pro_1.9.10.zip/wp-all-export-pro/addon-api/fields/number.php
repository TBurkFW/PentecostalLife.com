<?php

namespace Wpae\AddonAPI;

class PMXE_Addon_Number_Field extends PMXE_Addon_Field {

    public function toString() {
        return $this->value;
    }
}
