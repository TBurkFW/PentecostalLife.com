<?php

namespace Wpae\AddonAPI;

class PMXE_Addon_Select_Field extends PMXE_Addon_Switcher_Field {

}

