<?php

namespace Wpae\AddonAPI;

class PMXE_Addon_Checkbox_Field extends PMXE_Addon_Switcher_Field {

}
