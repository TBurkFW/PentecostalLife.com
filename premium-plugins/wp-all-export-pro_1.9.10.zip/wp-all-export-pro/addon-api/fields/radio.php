<?php

namespace Wpae\AddonAPI;

class PMXE_Addon_Radio_Field extends PMXE_Addon_Switcher_Field {
}
