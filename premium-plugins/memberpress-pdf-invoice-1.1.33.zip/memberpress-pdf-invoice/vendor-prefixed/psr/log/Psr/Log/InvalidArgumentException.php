<?php

namespace MemberPress\PdfInvoice\Psr\Log;

class InvalidArgumentException extends \InvalidArgumentException
{
}
