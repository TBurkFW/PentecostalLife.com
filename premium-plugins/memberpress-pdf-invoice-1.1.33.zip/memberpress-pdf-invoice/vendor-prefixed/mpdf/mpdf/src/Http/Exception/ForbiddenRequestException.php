<?php

namespace MemberPress\PdfInvoice\Mpdf\Http\Exception;

class ForbiddenRequestException extends \MemberPress\PdfInvoice\Mpdf\MpdfException
{

}
