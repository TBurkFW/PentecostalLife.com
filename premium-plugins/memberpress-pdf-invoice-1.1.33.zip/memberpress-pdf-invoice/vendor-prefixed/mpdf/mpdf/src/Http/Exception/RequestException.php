<?php

namespace MemberPress\PdfInvoice\Mpdf\Http\Exception;

class RequestException extends \MemberPress\PdfInvoice\Mpdf\MpdfException
{

}
