<?php

namespace MemberPress\PdfInvoice\Mpdf\Http\Exception;

class NetworkException extends \MemberPress\PdfInvoice\Mpdf\MpdfException
{

}
