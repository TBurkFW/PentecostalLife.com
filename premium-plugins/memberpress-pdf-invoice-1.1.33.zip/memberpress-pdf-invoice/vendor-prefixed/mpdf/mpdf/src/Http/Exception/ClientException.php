<?php

namespace MemberPress\PdfInvoice\Mpdf\Http\Exception;

class ClientException extends \MemberPress\PdfInvoice\Mpdf\MpdfException
{

}
