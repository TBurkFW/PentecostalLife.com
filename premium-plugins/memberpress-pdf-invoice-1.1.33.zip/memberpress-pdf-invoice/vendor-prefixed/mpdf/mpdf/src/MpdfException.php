<?php

namespace MemberPress\PdfInvoice\Mpdf;

class MpdfException extends \ErrorException
{

}
