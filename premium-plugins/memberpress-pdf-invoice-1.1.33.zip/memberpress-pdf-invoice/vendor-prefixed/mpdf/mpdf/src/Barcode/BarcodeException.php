<?php

namespace MemberPress\PdfInvoice\Mpdf\Barcode;

class BarcodeException extends \MemberPress\PdfInvoice\Mpdf\MpdfException
{

}
