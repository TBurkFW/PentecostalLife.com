<?php

namespace MemberPress\PdfInvoice\Mpdf\Container;

class NotFoundException extends \MemberPress\PdfInvoice\Mpdf\MpdfException
{

}
