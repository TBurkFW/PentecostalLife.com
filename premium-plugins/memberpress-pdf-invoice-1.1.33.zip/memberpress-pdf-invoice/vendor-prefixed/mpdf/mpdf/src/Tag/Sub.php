<?php

namespace MemberPress\PdfInvoice\Mpdf\Tag;

class Sub extends InlineTag
{


}
