<?php

namespace MemberPress\PdfInvoice\Mpdf\Tag;

class H3 extends BlockTag
{


}
