<?php

namespace MemberPress\PdfInvoice\Mpdf\Tag;

class S extends InlineTag
{


}
