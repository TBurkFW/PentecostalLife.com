<?php

namespace MemberPress\PdfInvoice\Mpdf\Tag;

class Mark extends InlineTag
{


}
