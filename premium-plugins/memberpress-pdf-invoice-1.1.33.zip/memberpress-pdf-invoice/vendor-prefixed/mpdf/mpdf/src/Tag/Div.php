<?php

namespace MemberPress\PdfInvoice\Mpdf\Tag;

class Div extends BlockTag
{


}
