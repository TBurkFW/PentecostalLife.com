<?php

namespace MemberPress\PdfInvoice\Mpdf\Tag;

class Figure extends BlockTag
{


}
