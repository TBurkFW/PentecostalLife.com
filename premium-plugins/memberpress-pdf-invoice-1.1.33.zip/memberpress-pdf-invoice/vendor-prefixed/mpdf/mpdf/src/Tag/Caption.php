<?php

namespace MemberPress\PdfInvoice\Mpdf\Tag;

class Caption extends BlockTag
{


}
