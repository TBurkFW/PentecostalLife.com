<?php

namespace MemberPress\PdfInvoice\Mpdf\Tag;

class Address extends BlockTag
{


}
