<?php

namespace MemberPress\PdfInvoice\Mpdf\Tag;

class P extends BlockTag
{


}
