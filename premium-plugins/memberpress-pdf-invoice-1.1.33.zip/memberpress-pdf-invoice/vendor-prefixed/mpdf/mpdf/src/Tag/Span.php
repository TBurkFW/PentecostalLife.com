<?php

namespace MemberPress\PdfInvoice\Mpdf\Tag;

class Span extends InlineTag
{


}
