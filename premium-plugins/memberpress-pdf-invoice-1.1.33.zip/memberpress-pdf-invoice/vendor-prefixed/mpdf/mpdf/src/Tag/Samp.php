<?php

namespace MemberPress\PdfInvoice\Mpdf\Tag;

class Samp extends InlineTag
{


}
