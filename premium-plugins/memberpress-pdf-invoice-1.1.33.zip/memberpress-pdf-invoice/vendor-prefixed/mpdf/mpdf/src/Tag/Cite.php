<?php

namespace MemberPress\PdfInvoice\Mpdf\Tag;

class Cite extends InlineTag
{


}
