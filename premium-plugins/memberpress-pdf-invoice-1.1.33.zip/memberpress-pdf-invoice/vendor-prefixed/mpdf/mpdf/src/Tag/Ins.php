<?php

namespace MemberPress\PdfInvoice\Mpdf\Tag;

class Ins extends InlineTag
{


}
