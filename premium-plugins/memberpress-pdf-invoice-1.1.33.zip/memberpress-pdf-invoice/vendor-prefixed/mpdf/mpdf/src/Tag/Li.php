<?php

namespace MemberPress\PdfInvoice\Mpdf\Tag;

class Li extends BlockTag
{


}
