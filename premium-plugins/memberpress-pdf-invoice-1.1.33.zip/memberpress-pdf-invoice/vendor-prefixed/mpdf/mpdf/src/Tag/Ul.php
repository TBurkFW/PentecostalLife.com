<?php

namespace MemberPress\PdfInvoice\Mpdf\Tag;

class Ul extends BlockTag
{


}
