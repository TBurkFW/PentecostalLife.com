<?php

namespace MemberPress\PdfInvoice\Mpdf\Tag;

class Article extends BlockTag
{


}
