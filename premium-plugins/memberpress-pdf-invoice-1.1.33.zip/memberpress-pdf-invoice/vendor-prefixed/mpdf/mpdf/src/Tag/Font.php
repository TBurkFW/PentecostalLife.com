<?php

namespace MemberPress\PdfInvoice\Mpdf\Tag;

class Font extends InlineTag
{


}
