<?php

namespace MemberPress\PdfInvoice\Mpdf\Tag;

class I extends InlineTag
{


}
