<?php

namespace MemberPress\PdfInvoice\Mpdf\Tag;

class Kbd extends InlineTag
{


}
