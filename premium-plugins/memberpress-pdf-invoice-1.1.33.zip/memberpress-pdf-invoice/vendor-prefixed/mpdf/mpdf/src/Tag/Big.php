<?php

namespace MemberPress\PdfInvoice\Mpdf\Tag;

class Big extends InlineTag
{


}
