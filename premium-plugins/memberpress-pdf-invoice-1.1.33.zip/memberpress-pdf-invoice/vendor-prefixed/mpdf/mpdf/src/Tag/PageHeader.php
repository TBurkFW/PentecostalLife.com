<?php

namespace MemberPress\PdfInvoice\Mpdf\Tag;

class PageHeader extends PageFooter
{

}
