<?php

namespace MemberPress\PdfInvoice\Mpdf\Tag;

class Footer extends BlockTag
{


}
