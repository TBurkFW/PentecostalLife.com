<?php

namespace MemberPress\PdfInvoice\Mpdf\Tag;

class U extends InlineTag
{


}
