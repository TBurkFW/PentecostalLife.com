<?php

namespace MemberPress\PdfInvoice\Mpdf\Tag;

class BlockQuote extends BlockTag
{


}
