<?php

namespace MemberPress\PdfInvoice\Mpdf\Tag;

class Tt extends InlineTag
{


}
