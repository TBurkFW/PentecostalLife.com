<?php

namespace MemberPress\PdfInvoice\Mpdf\Tag;

class Q extends InlineTag
{


}
