<?php

namespace MemberPress\PdfInvoice\Mpdf\Tag;

class H5 extends BlockTag
{


}
