<?php

namespace MemberPress\PdfInvoice\Mpdf\Tag;

class HGroup extends BlockTag
{


}
