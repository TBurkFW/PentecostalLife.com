<?php

namespace MemberPress\PdfInvoice\Mpdf\Tag;

class Del extends InlineTag
{


}
