<?php

namespace MemberPress\PdfInvoice\Mpdf\Tag;

class PageBreak extends FormFeed
{

}
