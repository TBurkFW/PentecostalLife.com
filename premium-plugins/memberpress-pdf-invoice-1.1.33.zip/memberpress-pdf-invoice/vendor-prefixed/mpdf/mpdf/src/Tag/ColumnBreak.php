<?php

namespace MemberPress\PdfInvoice\Mpdf\Tag;

class ColumnBreak extends NewColumn
{

}
