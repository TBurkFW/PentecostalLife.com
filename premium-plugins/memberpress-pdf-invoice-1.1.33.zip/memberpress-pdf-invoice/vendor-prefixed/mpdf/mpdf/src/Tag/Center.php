<?php

namespace MemberPress\PdfInvoice\Mpdf\Tag;

class Center extends BlockTag
{


}
