<?php

namespace MemberPress\PdfInvoice\Mpdf\Tag;

class Code extends InlineTag
{


}
