<?php

namespace MemberPress\PdfInvoice\Mpdf\Tag;

class SetPageFooter extends SetHtmlPageFooter
{


}
