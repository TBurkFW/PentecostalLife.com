<?php

namespace MemberPress\PdfInvoice\Mpdf\Tag;

class Small extends InlineTag
{


}
