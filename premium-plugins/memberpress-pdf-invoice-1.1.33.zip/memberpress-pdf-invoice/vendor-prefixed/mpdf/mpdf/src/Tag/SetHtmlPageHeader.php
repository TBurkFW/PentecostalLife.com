<?php

namespace MemberPress\PdfInvoice\Mpdf\Tag;

class SetHtmlPageHeader extends SetHtmlPageFooter
{


}
