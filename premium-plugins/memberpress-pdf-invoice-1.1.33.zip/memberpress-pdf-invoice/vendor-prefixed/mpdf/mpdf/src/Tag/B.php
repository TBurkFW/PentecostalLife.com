<?php

namespace MemberPress\PdfInvoice\Mpdf\Tag;

class B extends InlineTag
{


}
