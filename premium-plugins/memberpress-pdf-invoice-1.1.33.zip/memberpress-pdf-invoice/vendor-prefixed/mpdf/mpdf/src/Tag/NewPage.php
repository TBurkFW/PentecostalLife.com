<?php

namespace MemberPress\PdfInvoice\Mpdf\Tag;

class NewPage extends FormFeed
{

}
