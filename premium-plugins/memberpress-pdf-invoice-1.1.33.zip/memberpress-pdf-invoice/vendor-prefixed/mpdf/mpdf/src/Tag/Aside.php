<?php

namespace MemberPress\PdfInvoice\Mpdf\Tag;

class Aside extends BlockTag
{


}
