<?php

namespace MemberPress\PdfInvoice\Mpdf\Tag;

class Dt extends BlockTag
{


}
