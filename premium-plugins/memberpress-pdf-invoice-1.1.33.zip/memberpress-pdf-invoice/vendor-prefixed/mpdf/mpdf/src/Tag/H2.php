<?php

namespace MemberPress\PdfInvoice\Mpdf\Tag;

class H2 extends BlockTag
{


}
