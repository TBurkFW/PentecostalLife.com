<?php

namespace MemberPress\PdfInvoice\Mpdf\Tag;

class FigCaption extends BlockTag
{


}
