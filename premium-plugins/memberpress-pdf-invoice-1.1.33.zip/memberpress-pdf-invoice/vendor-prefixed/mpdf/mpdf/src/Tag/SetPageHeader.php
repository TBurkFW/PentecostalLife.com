<?php

namespace MemberPress\PdfInvoice\Mpdf\Tag;

class SetPageHeader extends SetHtmlPageFooter
{


}
