<?php

namespace MemberPress\PdfInvoice\Mpdf\Tag;

class Dd extends BlockTag
{


}
