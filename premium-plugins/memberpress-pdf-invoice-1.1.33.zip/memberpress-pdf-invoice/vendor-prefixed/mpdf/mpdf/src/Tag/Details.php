<?php

namespace MemberPress\PdfInvoice\Mpdf\Tag;

class Details extends BlockTag
{


}
