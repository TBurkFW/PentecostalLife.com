<?php

namespace MemberPress\PdfInvoice\Mpdf\Tag;

class H6 extends BlockTag
{


}
