<?php

namespace MemberPress\PdfInvoice\Mpdf\Tag;

class Dl extends BlockTag
{


}
