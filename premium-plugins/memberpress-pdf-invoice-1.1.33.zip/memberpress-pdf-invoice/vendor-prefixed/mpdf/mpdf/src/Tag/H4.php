<?php

namespace MemberPress\PdfInvoice\Mpdf\Tag;

class H4 extends BlockTag
{


}
