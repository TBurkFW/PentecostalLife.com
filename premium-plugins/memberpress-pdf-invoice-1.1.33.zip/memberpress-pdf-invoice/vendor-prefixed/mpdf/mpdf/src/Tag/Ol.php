<?php

namespace MemberPress\PdfInvoice\Mpdf\Tag;

class Ol extends BlockTag
{


}
