<?php

namespace MemberPress\PdfInvoice\Mpdf\Tag;

class Main extends BlockTag
{


}
