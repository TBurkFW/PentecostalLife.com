<?php

namespace MemberPress\PdfInvoice\Mpdf\Tag;

class Nav extends BlockTag
{


}
