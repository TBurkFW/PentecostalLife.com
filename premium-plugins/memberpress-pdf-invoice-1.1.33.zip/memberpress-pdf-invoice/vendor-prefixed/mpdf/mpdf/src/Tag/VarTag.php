<?php

namespace MemberPress\PdfInvoice\Mpdf\Tag;

class VarTag extends InlineTag
{


}
