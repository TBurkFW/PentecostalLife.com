<?php

namespace MemberPress\PdfInvoice\Mpdf\Tag;

class Bdi extends InlineTag
{


}
