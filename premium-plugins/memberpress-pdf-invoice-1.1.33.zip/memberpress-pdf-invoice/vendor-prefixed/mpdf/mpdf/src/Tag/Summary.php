<?php

namespace MemberPress\PdfInvoice\Mpdf\Tag;

class Summary extends BlockTag
{


}
