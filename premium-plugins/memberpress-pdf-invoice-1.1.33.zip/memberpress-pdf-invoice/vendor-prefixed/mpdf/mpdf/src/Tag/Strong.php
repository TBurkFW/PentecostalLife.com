<?php

namespace MemberPress\PdfInvoice\Mpdf\Tag;

class Strong extends InlineTag
{


}
