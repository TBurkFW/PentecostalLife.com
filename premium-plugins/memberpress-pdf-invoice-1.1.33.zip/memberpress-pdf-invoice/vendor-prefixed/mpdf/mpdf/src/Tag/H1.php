<?php

namespace MemberPress\PdfInvoice\Mpdf\Tag;

class H1 extends BlockTag
{


}
