<?php

namespace MemberPress\PdfInvoice\Mpdf\Tag;

class Time extends InlineTag
{


}
