<?php

namespace MemberPress\PdfInvoice\Mpdf\Tag;

class Acronym extends InlineTag
{


}
