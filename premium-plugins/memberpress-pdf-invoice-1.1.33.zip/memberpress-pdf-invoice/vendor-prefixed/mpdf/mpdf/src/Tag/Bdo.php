<?php

namespace MemberPress\PdfInvoice\Mpdf\Tag;

class Bdo extends InlineTag
{


}
