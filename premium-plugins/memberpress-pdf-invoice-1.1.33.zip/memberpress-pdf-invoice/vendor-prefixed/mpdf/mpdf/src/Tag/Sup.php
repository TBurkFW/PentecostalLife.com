<?php

namespace MemberPress\PdfInvoice\Mpdf\Tag;

class Sup extends InlineTag
{


}
