<?php

namespace MemberPress\PdfInvoice\Mpdf;

interface Watermark
{

}
