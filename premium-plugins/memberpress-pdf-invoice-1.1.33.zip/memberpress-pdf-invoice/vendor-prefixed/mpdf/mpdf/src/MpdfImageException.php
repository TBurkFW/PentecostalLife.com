<?php

namespace MemberPress\PdfInvoice\Mpdf;

class MpdfImageException extends \MemberPress\PdfInvoice\Mpdf\MpdfException
{

}
