<?php

namespace MemberPress\PdfInvoice\Mpdf\Exception;

class InvalidArgumentException extends \MemberPress\PdfInvoice\Mpdf\MpdfException
{

}
