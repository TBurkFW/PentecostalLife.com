<?php

namespace MemberPress\PdfInvoice\Mpdf\Exception;

class AssetFetchingException extends \MemberPress\PdfInvoice\Mpdf\MpdfException
{

}
