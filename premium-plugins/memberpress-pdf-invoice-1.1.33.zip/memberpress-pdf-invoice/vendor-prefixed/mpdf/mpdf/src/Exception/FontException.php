<?php

namespace MemberPress\PdfInvoice\Mpdf\Exception;

class FontException extends \MemberPress\PdfInvoice\Mpdf\MpdfException
{

}
