<?php

namespace MemberPress\PdfInvoice\DeepCopy\Exception;

use UnexpectedValueException;

class CloneException extends UnexpectedValueException
{
} 