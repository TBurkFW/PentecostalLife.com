<?php

namespace MemberPress\PdfInvoice\DeepCopy\Exception;

use ReflectionException;

class PropertyException extends ReflectionException
{
}
