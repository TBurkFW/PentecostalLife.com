<?php

function pmui_do_not_send_password_notification( $is_notify, $user, $userdata )
{
	return false;
}