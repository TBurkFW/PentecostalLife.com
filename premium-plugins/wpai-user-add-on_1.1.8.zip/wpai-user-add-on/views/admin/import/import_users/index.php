<!-- User Account Info Section -->

<?php include( 'user_personal_section.php' ); ?>

<!-- Other User Info Section -->

<?php include( 'user_other_section.php' ); ?>