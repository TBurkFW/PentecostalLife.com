<h2><?php _e('WP All Import Help', 'wp-all-import-pro') ?></h2>
	
