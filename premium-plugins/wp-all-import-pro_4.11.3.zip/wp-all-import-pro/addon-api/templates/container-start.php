<div class="postbox default rad4 pmxi-addon-group" data-group="<?php echo $group['id']; ?>" data-test="group">
    <h3 class="postbox-title">
        <span><?php echo $group['label']; ?></span>
    </h3>
    <div class="postbox-content">