<input type="text" placeholder="" value="<?php echo esc_attr($field_value); ?>" name="<?php echo esc_attr($html_name); ?>" class="text widefat rad4" data-test="input" style="width:200px;" />
