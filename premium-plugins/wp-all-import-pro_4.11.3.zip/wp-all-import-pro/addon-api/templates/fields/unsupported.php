<p>
    <?php
    printf(
        __('The field <b>%s</b> is currently not supported. Please contact support for more information.', 'wp-all-import-pro'),
        $field['type']
    );
    ?>
</p>