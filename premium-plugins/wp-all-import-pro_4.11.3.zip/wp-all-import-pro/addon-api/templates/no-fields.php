<p class="pmxi-no-fields">
    <?php echo __("No fields found for this group.", 'wp-all-import-pro'); ?>
</p>