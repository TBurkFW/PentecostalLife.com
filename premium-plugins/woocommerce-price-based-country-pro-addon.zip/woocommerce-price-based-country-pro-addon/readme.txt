=== WooCommerce Price Based on Country Pro ===

Contributors: oscargare
Tags: woocommerce, price based country, price by country
Requires at least: 4.4
Tested up to: 6.8
Stable tag: 3.7.0
WC requires at least: 4.0
WC tested up to: 9.8
License: GNU General Public License v3.0
License URI: http://www.gnu.org/licenses/gpl-3.0.html

Supercharge Price Based on Country with professionals features.

== Description ==

Supercharge Price Based on Country with professionals features.
