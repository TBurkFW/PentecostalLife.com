<?php
function pmpro_display_user_level() {
    if ( is_user_logged_in() ) {
        $user_id = get_current_user_id();
        $level = pmpro_getMembershipLevelForUser( $user_id );
        if ( ! empty( $level ) ) {
            return esc_html( $level->name );
        } else {
            return 'Guest'; // Logged in, but no level
        }
    } else {
        return 'Guest'; // Not logged in
    }
}
add_shortcode( 'user_membership_level', 'pmpro_display_user_level' );

