<?php
function show_articles_linked_to_current_issue( $query ) {
	if ( is_singular( 'issue' ) ) {
		$current_issue_id = get_the_ID();

		// Always apply this meta_query filter regardless of other filters
		$meta_query = $query->get( 'meta_query' );
		if ( ! $meta_query ) {
			$meta_query = [];
		}

		$meta_query[] = [
			'key'     => 'related_issue',
			'value'   => $current_issue_id,
			'compare' => '='
		];

		$query->set( 'meta_query', $meta_query );
	}
}
add_action( 'elementor/query/issue_articles', 'show_articles_linked_to_current_issue' );
