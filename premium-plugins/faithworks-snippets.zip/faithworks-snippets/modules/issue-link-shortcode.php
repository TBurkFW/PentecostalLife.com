<?php
function show_related_issue_link() {
    global $post;

    // Get Pods object for the current post
    $pods = pods( get_post_type( $post ), $post->ID );

    // Get related issue (assuming field name is 'related_issue')
    $related_issue = $pods->field( 'related_issue' );

    if ( is_array( $related_issue ) && isset( $related_issue[ 'ID' ] ) ) {
        // If it's a single post relationship
        $issue_post = get_post( $related_issue['ID'] );
    } elseif ( is_object( $related_issue ) && isset( $related_issue->ID ) ) {
        // Some setups return object instead of array
        $issue_post = get_post( $related_issue->ID );
    } else {
        return ''; // No related issue
    }

    if ( $issue_post ) {
        $title = get_the_title( $issue_post );
        $url   = get_permalink( $issue_post );
        return '<a href="' . esc_url( $url ) . '">' . esc_html( $title ) . '</a>';
    }

    return '';
}
add_shortcode( 'related_issue_link', 'show_related_issue_link' );
