<?php
// 1a. Shortcode for dynamic year dropdown with no page reload (JS handles fetch)
add_shortcode('ajax_issue_year_dropdown', function() {
    global $wpdb;

    $years = $wpdb->get_col("
        SELECT DISTINCT YEAR(meta_value) 
        FROM {$wpdb->prefix}postmeta 
        WHERE meta_key = 'issue_date' 
        AND meta_value != '' 
        AND meta_value != '0000-00-00'
        ORDER BY meta_value DESC
    ");

    $output = '<select id="ajax-issue-year-dropdown" class="ajax-filter-dropdown">';
    $output .= '<option value="">All Years</option>';

    foreach ($years as $year) {
        $output .= "<option value='{$year}'>{$year}</option>";
    }

    $output .= '</select>';

    return $output;
});

// 1b. Elementor query filter to apply the year filter
add_action('elementor/query/sort_by_issue_date', function( $query ) {
    if ( isset($_GET['issue_year']) && is_numeric($_GET['issue_year']) ) {
        $year = sanitize_text_field($_GET['issue_year']);

        $query->set('meta_query', [[
            'key'     => 'issue_date',
            'value'   => [$year . '-01-01', $year . '-12-31'],
            'compare' => 'BETWEEN',
            'type'    => 'DATE'
        ]]);
    }

    $query->set('meta_key', 'issue_date');
    $query->set('orderby', 'meta_value');
    $query->set('order', 'DESC');
});
