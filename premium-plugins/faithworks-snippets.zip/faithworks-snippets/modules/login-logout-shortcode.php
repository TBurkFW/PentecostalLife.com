<?php
function toggle_login_logout_link() {
    if ( is_user_logged_in() ) {
        // Custom logout URL
        $logout_url = 'https://www.pentecostallife.com/my-account/customer-logout';
        return '<a href="' . esc_url( $logout_url ) . '">Logout</a>';
    } else {
        // Custom login URL
        $login_url = 'https://www.pentecostallife.com/my-account/';
        return '<a href="' . esc_url( $login_url ) . '">Login</a>';
    }
}
add_shortcode( 'login_logout_link', 'toggle_login_logout_link' );
