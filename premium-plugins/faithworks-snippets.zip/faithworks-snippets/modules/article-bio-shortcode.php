<?php
function shortcode_article_author_bio_custom_field() {
    global $post;

    $terms = get_the_terms($post->ID, 'article-author');

    if (!empty($terms) && !is_wp_error($terms)) {
        // Use the first author term
        $author = $terms[0];

        // Get the custom field value for 'author_bio'
        $bio = get_term_meta($author->term_id, 'author_bio', true);
        $name = esc_html($author->name);

        if (!empty($bio)) {
            return wp_kses_post($bio);
        } else {
            return $name . ' is a contributor to Pentecostal Life.';
        }
    }

    return '';
}
add_shortcode('author_bio', 'shortcode_article_author_bio_custom_field');
