<?php
// 1. Add custom column for 'related_issue'
add_filter('manage_article_posts_columns', function($columns) {
    $columns['related_issue_column'] = 'Related Issue';
    return $columns;
});

add_action('manage_article_posts_custom_column', function($column, $post_id) {
    if ($column === 'related_issue_column') {
        $related_id = get_post_meta($post_id, 'related_issue', true);
        if ($related_id) {
            echo esc_html(get_the_title($related_id));
        } else {
            echo '—';
        }
    }
}, 10, 2);

// 2. Add dropdown to Quick Edit and Bulk Edit
add_action('quick_edit_custom_box', 'related_issue_quick_edit_dropdown', 10, 2);
add_action('bulk_edit_custom_box', 'related_issue_quick_edit_dropdown', 10, 2);

function related_issue_quick_edit_dropdown($column_name, $post_type) {
    if ($post_type !== 'article' || $column_name !== 'related_issue_column') return;

    $issues = get_posts([
        'post_type' => 'issue',
        'posts_per_page' => -1,
        'orderby' => 'date',
        'order' => 'DESC',
    ]);
    ?>
    <fieldset class="inline-edit-col-right">
        <div class="inline-edit-col">
            <label>
                <span class="title">Related Issue</span>
                <select name="related_issue" class="related_issue">
                    <option value="">— Select Issue —</option>
                    <?php foreach ($issues as $issue): ?>
                        <option value="<?php echo esc_attr($issue->ID); ?>">
                            <?php echo esc_html($issue->post_title); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </label>
        </div>
    </fieldset>
    <?php
}

// 3. Populate dropdown on Quick Edit
add_action('admin_footer', function() {
    global $post_type;
    if ($post_type !== 'article') return;
    ?>
    <script>
    jQuery(function($) {
        $('a.editinline').on('click', function() {
            var $tr = $(this).closest('tr');
            var post_id = $tr.attr('id').replace('post-', '');
            var issueTitle = $tr.find('.column-related_issue_column').text().trim();
            var $select = $('select.related_issue', '.inline-edit-row');

            $select.val(''); // Reset

            $select.find('option').each(function() {
                if ($(this).text().trim() === issueTitle) {
                    $select.val($(this).val());
                }
            });
        });
    });
    </script>
    <?php
});

// 4. Save related_issue on Quick Edit
add_action('save_post', function($post_id) {
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
    if (!current_user_can('edit_post', $post_id)) return;

    if (isset($_POST['related_issue'])) {
        update_post_meta($post_id, 'related_issue', sanitize_text_field($_POST['related_issue']));
    }
});

// 5. AJAX for saving Bulk Edit
add_action('admin_footer-edit.php', function() {
    global $post_type;
    if ($post_type !== 'article') return;
    ?>
    <script>
    jQuery(function($) {
        $('#bulk_edit').on('click', function(e) {
            e.preventDefault();
            var $bulkRow = $('#bulk-edit');
            var relatedIssue = $bulkRow.find('select[name="related_issue"]').val();
            var postIDs = [];

            $bulkRow.find('#bulk-titles li').each(function() {
                postIDs.push($(this).attr('id').replace(/^ttle/, ''));
            });

            if (postIDs.length > 0 && relatedIssue !== '') {
                $.ajax({
                    url: ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'save_bulk_related_issue',
                        post_ids: postIDs,
                        related_issue: relatedIssue,
                    },
                    success: function() {
                        location.reload();
                    }
                });
            }
        });
    });
    </script>
    <?php
});

// 6. Handle AJAX bulk save
add_action('wp_ajax_save_bulk_related_issue', function() {
    if (!current_user_can('edit_posts')) wp_die();

    $post_ids = $_POST['post_ids'] ?? [];
    $related_issue = sanitize_text_field($_POST['related_issue'] ?? '');

    foreach ($post_ids as $post_id) {
        update_post_meta($post_id, 'related_issue', $related_issue);
    }

    wp_die();
});
