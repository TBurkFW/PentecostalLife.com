<?php
add_filter('woocommerce_get_price_html', 'show_minimum_tiered_total_price_everywhere', 10, 2);

function show_minimum_tiered_total_price_everywhere($price_html, $product) {
    if (!function_exists('tpt_fs') || !$product instanceof WC_Product) {
        return $price_html;
    }

    if (class_exists('\TierPricingTable\PriceManager')) {
        $product_id = $product->get_id();
        $pricing_rules = \TierPricingTable\PriceManager::getPricingRule($product_id);

        if (!empty($pricing_rules) && is_array($pricing_rules)) {
            $min_qty = min(array_keys($pricing_rules));
            $unit_price = (float) $pricing_rules[$min_qty];
            $total_price = $min_qty * $unit_price;

            return wc_price($total_price) . ' / year';
        }
    }

    return $price_html;
}
