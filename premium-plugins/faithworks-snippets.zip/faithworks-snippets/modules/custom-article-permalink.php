<?php
function custom_article_permalink($post_link, $post) {
    if ('article' !== get_post_type($post)) {
        return $post_link;
    }

    $terms = get_the_terms($post->ID, 'article_category');
    if (!empty($terms) && !is_wp_error($terms)) {
        return str_replace('%article_category%', $terms[0]->slug, $post_link);
    }

    // Fallback if no term is assigned
    return str_replace('%article_category%', 'uncategorized', $post_link);
}
add_filter('post_type_link', 'custom_article_permalink', 10, 2);
