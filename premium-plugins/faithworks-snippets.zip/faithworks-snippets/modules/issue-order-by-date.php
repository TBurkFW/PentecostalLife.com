<?php
add_action('elementor/query/issue_archive', function( $query ) {
    // Filter by year if provided via URL (?issue_year=2024)
    if ( isset($_GET['issue_year']) && is_numeric($_GET['issue_year']) ) {
        $year = sanitize_text_field($_GET['issue_year']);

        $query->set('meta_query', array(
            array(
                'key'     => 'issue_date', // ← Replace with your actual Pods field slug if different
                'value'   => array( $year . '-01-01', $year . '-12-31' ),
                'compare' => 'BETWEEN',
                'type'    => 'DATE'
            )
        ));
    }

    // Always sort by the custom issue_date field
    $query->set('meta_key', 'issue_date');
    $query->set('orderby', 'meta_value');
    $query->set('order', 'DESC');
});
