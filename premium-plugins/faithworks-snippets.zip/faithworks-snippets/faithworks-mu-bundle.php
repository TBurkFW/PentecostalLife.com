<?php
/*
Plugin Name: FaithWorks Snippet Bundle
Description: Assorted snippets
Version: 1.0.0
Author: Faith Works
*/

if ( ! defined( 'ABSPATH' ) ) { exit; }

define( 'FAITHWORKS_BUNDLE_VERSION', '1.0.0' );
define( 'FAITHWORKS_BUNDLE_DIR', plugin_dir_path( __FILE__ ) );
define( 'FAITHWORKS_BUNDLE_URL', plugin_dir_url( __FILE__ ) );

$__faithworks_modules = array(
    'article-bio-shortcode.php',
    'article-reading-time.php',
    'custom-article-permalink.php',
    'display-membership-shortcode.php',
    'display-min-qty-price.php',
    'issue-link-shortcode.php',
    'issue-order-by-date.php',
    'issue-year-dropdown.php',
    'limit-article-views-banner.php',
    'login-logout-shortcode.php',
    'related-issue-column.php',
    'show-articles-linked-to-current-issue.php',
);

$__base = FAITHWORKS_BUNDLE_DIR . 'modules/';
foreach ( $__faithworks_modules as $__rel ) {
    $__path = $__base . $__rel;
    if ( is_file( $__path ) ) {
        require_once $__path;
    }
}
