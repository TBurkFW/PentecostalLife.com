<?php

function pmwe_pmxe_addons_html() {
    echo "<input type='hidden' id='pmxe_woocommerce_addon_installed' value='1'>";
}