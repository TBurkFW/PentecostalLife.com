<?php

function pmue_pmxe_addons_html() {
    echo "<input type='hidden' id='pmxe_user_addon_installed' value='1'>";
}