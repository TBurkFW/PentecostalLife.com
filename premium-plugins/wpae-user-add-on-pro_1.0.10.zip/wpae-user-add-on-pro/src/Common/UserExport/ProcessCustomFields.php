<?php

namespace Pmue\Common\UserExport;


class ProcessCustomFields
{
    /**
     * @param $userId
     * @param $implode_delimiter
     * @param $fieldLabel
     * @param $fieldValue
     * @param $fieldSnipped
     * @param $article
     * @param $element_name
     * @return array
     */
    public function processCustomFields($userId, $implode_delimiter, $fieldLabel, $fieldValue, $fieldSnipped, $article, $element_name)
    {
        return $article;
    }

}