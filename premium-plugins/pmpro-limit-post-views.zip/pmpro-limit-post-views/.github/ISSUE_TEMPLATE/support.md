---
name: "💬 Support Question"
about: "If you have a question, please see our docs or use our helpdesk."
title: ''
labels: 'Type: support'
assignees: ''

---

We don't offer technical support on GitHub so we recommend using the following:

**Reading our documentation**
Usage docs can be found here: https://www.paidmembershipspro.com/documentation/

**Technical support for premium extensions or if you're an active paid member**
Submit a ticket on our helpdesk by visiting https://www.paidmembershipspro.com/new-topic/ (Please note that an [active paid membership](https://www.paidmembershipspro.com/pricing) is required for paid support.)

**General usage and development questions**
- WordPress.org Forums: https://wordpress.org/support/plugin/paid-memberships-pro
- Website: https://www.paidmembershipspro.com/contact/
