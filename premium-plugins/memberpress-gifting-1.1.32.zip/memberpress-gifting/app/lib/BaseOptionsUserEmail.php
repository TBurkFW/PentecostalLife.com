<?php
namespace memberpress\gifting\lib;
if(!defined('ABSPATH')) {die('You are not allowed to call this page directly.');}

abstract class BaseOptionsUserEmail extends BaseEmail {
  // we do nothing ... this class is purely for taxonomy
}

