<?php

if (!defined('ABSPATH')) {
    die('You are not allowed to call this page directly.');
} ?>
<div id="mepr-wizard-finish-step-container"><i class="mp-icon mp-icon-spinner animate-spin" aria-hidden="true"></i></div>