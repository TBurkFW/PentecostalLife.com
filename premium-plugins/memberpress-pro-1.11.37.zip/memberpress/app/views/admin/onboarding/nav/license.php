<?php if (!defined('ABSPATH')) {
    die('You are not allowed to call this page directly.');
} ?>
<div>
  <button type="button" class="mepr-wizard-button-blue mepr-wizard-go-to-step" data-step="2" data-context="continue"><?php esc_html_e('Continue', 'memberpress'); ?></button>
</div>
