<?php

if (!defined('ABSPATH')) {
    die('You are not allowed to call this page directly.');
} ?>

<div class="mepr-pie-chart-container">
  <div class="pie-chart-slice"></div>
</div>