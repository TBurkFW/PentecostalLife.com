<?php if (!defined('ABSPATH')) {
    die('You are not allowed to call this page directly.');
} ?>

<div id="mepr-logged-out-template">
  <span class="mepr-link-span"><a href="<?php echo esc_url($login_url); ?>"><?php _ex('Login', 'ui', 'memberpress'); ?></a></span>
</div>
