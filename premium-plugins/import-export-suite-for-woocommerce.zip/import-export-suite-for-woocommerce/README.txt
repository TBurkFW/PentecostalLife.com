=== Import Export Suite for WooCommerce ===
Contributors: webtoffee
Version: 1.3.3
Tags: CSV, Export, Import, WooCommerce, Wordpress, XML
Requires at least: 4.0
Requires PHP: 5.6
Tested up to: 6.8.2
Stable tag: 1.3.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Import export for WooCommerce

== Description ==
Product Page: https://woocommerce.com/products/import-export-suite-for-woocommerce/

== Installation ==
https://www.webtoffee.com/how-to-download-install-update-woocommerce-plugin/

== Frequently Asked Questions ==
Refer Product Page FAQ tab: https://www.webtoffee.com/product/woocommerce-import-export-suite/

== Screenshots ==
Refer Product Page Screenshots tab: https://www.webtoffee.com/product/woocommerce-import-export-suite/

== Changelog ==
Refer Product Page Changelog tab: https://www.webtoffee.com/product/woocommerce-import-export-suite/

== Upgrade Notice ==

= 1.3.3 =
[New] - Built-in SFTP support—no longer requires separate SFTP add-on.
[Compatibility] - Tested OK with WordPress 6.8.2
[Compatibility] - Tested OK with WooCommerce 10.0.2
