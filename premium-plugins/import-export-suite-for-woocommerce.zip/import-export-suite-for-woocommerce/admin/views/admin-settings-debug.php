<?php
/**
 * Debug view section
 *
 * @link
 *
 * @package ImportExportSuite
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="wt-iew-tab-content" data-id="<?php echo esc_html( $target_id ); ?>">
	
</div>
