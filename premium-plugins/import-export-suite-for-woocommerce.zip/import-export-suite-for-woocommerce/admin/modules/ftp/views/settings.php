<?php
/**
 * FTP setting page
 *
 * @package ImportExportSuite
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="wt-iew-tab-content wt_iew_ftp_settings_page" data-id="<?php echo esc_html( $target_id ); ?>">
	
</div>
