=== Tiered Pricing Table for WooCommerce ===

Contributors: bycrik
Tags: woocommerce, tiered pricing, dynamic price, price, wholesale
Requires at least: 4.2
Tested up to: 8.1.0
Requires PHP: 7.2

The plugin enables you to set quantity-based discounts and display these prices on the product page using various templates.

== Description ==