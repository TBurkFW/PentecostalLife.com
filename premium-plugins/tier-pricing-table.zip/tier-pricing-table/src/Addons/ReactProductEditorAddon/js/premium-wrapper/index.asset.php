<?php return array('dependencies' => array('react', 'wc-block-templates', 'wp-block-editor', 'wp-blocks'), 'version' => 'b0c3730f828040cd8442');
