<?php return array('dependencies' => array('react', 'wc-block-templates', 'wp-blocks', 'wp-components', 'wp-i18n'), 'version' => '90599d6f9194ced34e22');
