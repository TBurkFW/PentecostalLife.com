<?php return array('dependencies' => array('react', 'wc-block-templates', 'wp-blocks', 'wp-components', 'wp-core-data', 'wp-element', 'wp-i18n'), 'version' => '4cfdb04e9504721c76ac');
